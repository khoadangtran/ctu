package com.example.lab8;

public class CourseModal {
    private String courseName;
    private String courseDuration;
    private String courseTrack;
    private String courseDescription;
    private int id;

    public String getCourseName() {
        return courseName;
    }
    public void setCourseName(String courseName) {
        this.courseName = courseName;
    }

    public String getCourseDuration() {
        return courseDuration;
    }

    public void setCourseDuration(String courseDuration) {
        this.courseDuration = courseDuration;
    }

    public String getCourseTrack() {
        return courseTrack;
    }

    public void setCourseTrack(String courseTrack) {
        this.courseTrack = courseTrack;
    }

    public String getCourseDescription() {
        return courseDescription;
    }

    public void setCourseDescription(String courseDescription) {
        this.courseDescription = courseDescription;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
    public CourseModal(String courseName, String courseDuration, String courseTrack, String courseDescription) {
        this.courseName = courseName;
        this.courseDuration = courseDuration;
        this.courseTrack = courseTrack;
        this.courseDescription = courseDescription;

    }
}
