package com.example.lab8;

import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CourseAdapter extends RecyclerView.Adapter<CourseAdapter.ViewHolder> {
    private ArrayList<CourseModal> courseModalArrayList;
    private Context context;

    public CourseAdapter (ArrayList<CourseModal> courseModalArrayList, Context context) {
        this.courseModalArrayList = courseModalArrayList;
        this.context = context;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.course_view_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        CourseModal modal = courseModalArrayList.get(position);
        Log.d("Error", String.valueOf(modal));
        holder.tv_courseName.setText(modal.getCourseName());
        holder.tv_courseDur.setText(modal.getCourseDuration());
        holder.tv_courseTrack.setText(modal.getCourseTrack());
        holder.tv_courseDes.setText(modal.getCourseDescription());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(context, UpdateCourseActivity.class);
                intent.putExtra("Name", modal.getCourseName());
                intent.putExtra("Duration", modal.getCourseDuration());
                intent.putExtra("Track", modal.getCourseTrack());
                intent.putExtra("Description", modal.getCourseDescription());
                if (context != null) {
                    context.startActivity(intent);
                }
//                    Toast.makeText(context, "Hello", Toast.LENGTH_SHORT).show();
            }
        });
    }

    @Override
    public int getItemCount() {
        return courseModalArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        private TextView tv_courseName, tv_courseTrack, tv_courseDur, tv_courseDes;
        public ViewHolder (@NonNull View itemview) {
            super(itemview);
            tv_courseName = itemview.findViewById(R.id.tv_courseName);
            tv_courseDur = itemview.findViewById(R.id.tv_courseDur);
            tv_courseTrack = itemview.findViewById(R.id.tv_courseTrack);
            tv_courseDes  = itemview.findViewById(R.id.tv_courseDes);
        }
    }
}

