package com.example.lab8;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {

    private EditText c_name, c_dur, c_track, c_des;
    private Button add_btn, read_btn;
    private DBHandler dbHandler;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        c_name = findViewById(R.id.courseName);
        c_dur = findViewById(R.id.courseDur);
        c_track = findViewById(R.id.courseTrack);
        c_des = findViewById(R.id.courseDes);
        add_btn = findViewById(R.id.add_btn);
        read_btn = findViewById(R.id.read_btn);

        dbHandler = new DBHandler(MainActivity.this);

        add_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String courseName = c_name.getText().toString();
                String courseDur = c_dur.getText().toString();
                String courseTrack = c_track.getText().toString();
                String courseDes = c_des.getText().toString();

                if(courseName.isEmpty() && courseDur.isEmpty() && courseTrack.isEmpty() && courseDur.isEmpty() && courseDes.isEmpty() ){
                    Toast.makeText(MainActivity.this, "Please fill in all data", Toast.LENGTH_SHORT).show();
                    return;
                }

                dbHandler.addNewCourse(courseName, courseDur, courseTrack, courseDes);

                Toast.makeText(MainActivity.this, "Course has been added", Toast.LENGTH_SHORT).show();
                c_name.setText("");
                c_dur.setText("");
                c_track.setText("");
                c_des.setText("");
            }
        });

        read_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try{
                    Intent intent = new Intent(MainActivity.this,ViewCourseActivity.class);
                    startActivity(intent);
                } catch (Exception e){
                    Toast.makeText(MainActivity.this, "" + e, Toast.LENGTH_SHORT).show();
                }

            }
        });
    }
}