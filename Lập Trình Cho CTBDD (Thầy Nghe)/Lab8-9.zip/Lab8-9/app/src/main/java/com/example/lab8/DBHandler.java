package com.example.lab8;



import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHandler extends SQLiteOpenHelper {
    private static final String DB_NAME = "course_db";
    private static final int DB_VERSION = 1;
    private static final String TABLE_NAME = "mycourses";
    private static final String ID_COL = "ID";
    private static final String NAME_COL = "Name";
    private static final String DUR_COL = "Duration";
    private static final String TRACK_COL = "Track";
    private static final String DES_COL = "Description";

    public DBHandler (Context context) {
        super(context, DB_NAME,null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String query = "CREATE TABLE " + TABLE_NAME + " ("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + NAME_COL + " TEXT, "
                + DUR_COL + " TEXT,"
                + TRACK_COL + " TEXT,"
                + DES_COL + " TEXT)";
        db.execSQL(query);
    }
    public void addNewCourse (String courseName, String courseDuration, String courseTrack, String courseDescription) {
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put (NAME_COL, courseName);
        values.put (DUR_COL, courseDuration);
        values.put (TRACK_COL, courseTrack);
        values.put (DES_COL, courseDescription);

        db.insert(TABLE_NAME, null, values);
        db.close();
    }

    public ArrayList<CourseModal> readCourses(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);
        ArrayList <CourseModal> courseModalArrayList = new ArrayList<>();
        if (cursor.moveToFirst()) {
            do {
                courseModalArrayList.add(new CourseModal(
                        cursor.getString(1),
                        cursor.getString(2),
                        cursor.getString(3),
                        cursor.getString(4)));
            } while (cursor.moveToNext());
        }
        cursor.close();
        return courseModalArrayList;
    }

    public void updateCourse(String originalCourseName, String courseName, String courseDuration, String courseTrack, String courseDescription){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        values.put (NAME_COL, courseName);
        values.put (DUR_COL, courseDuration);
        values.put (TRACK_COL, courseTrack);
        values.put (DES_COL, courseDescription);

        db.update(TABLE_NAME, values,"Name=?",new String[]{originalCourseName});
        db.close();
    }

    public void deleteCourse(String courseName){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(TABLE_NAME, "Name=?", new String[]{courseName});
        db.close();
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME );
        onCreate(db);
    }
}
