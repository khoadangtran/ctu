package com.example.lab8;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

public class UpdateCourseActivity extends AppCompatActivity {
    EditText course_name, course_dur, course_track, course_des;
    Button update_btn, delete_btn;
    DBHandler dbHandler;
    String courseName, courseDur, courseTrack, courseDes;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_course);

        course_name = findViewById(R.id.course_name);
        course_dur = findViewById(R.id.course_dur);
        course_track = findViewById(R.id.course_track);
        course_des = findViewById(R.id.course_des);
        update_btn = findViewById(R.id.update_btn);
        delete_btn = findViewById(R.id.delete_btn);

        dbHandler = new DBHandler(UpdateCourseActivity.this);

        courseName = getIntent().getStringExtra("Name");
        courseDur = getIntent().getStringExtra("Duration");
        courseTrack = getIntent().getStringExtra("Track");
        courseDes = getIntent().getStringExtra("Description");

        course_name.setText(courseName);
        course_dur.setText(courseDur);
        course_track.setText(courseTrack);
        course_des.setText(courseDes);

        update_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.updateCourse(courseName, course_name.getText().toString(), course_dur.getText().toString(), course_track.getText().toString(), course_des.getText().toString());
                Toast.makeText(UpdateCourseActivity.this, "Course Updated", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateCourseActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

        delete_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                dbHandler.deleteCourse(courseName);
                Toast.makeText(UpdateCourseActivity.this, "Deleted the course", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateCourseActivity.this, MainActivity.class);
                startActivity(i);
            }
        });

    }
}

