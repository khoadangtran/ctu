package com.example.lab8;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class ViewCourseActivity extends AppCompatActivity {
    private ArrayList<CourseModal> courseModalArrayList;
    private DBHandler dbHandler;
    private CourseAdapter courseAdapter;
    private RecyclerView r_view;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_course);
        r_view = findViewById(R.id.course_rv);

        dbHandler = new DBHandler(ViewCourseActivity.this);
        courseModalArrayList = dbHandler.readCourses();

        courseAdapter = new CourseAdapter(courseModalArrayList, ViewCourseActivity.this);
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewCourseActivity.this, RecyclerView.VERTICAL, false);
        r_view.setLayoutManager(linearLayoutManager);

        r_view.setAdapter(courseAdapter);


    }
}

