package com.example.lab10;

import java.time.LocalDateTime;

public class NoteModel {
    private int id;
    private String name;
    private String content;
    private String time;

    public NoteModel(int i, String n, String c, String d){
        this.id = i;
        this.name = n;
        this.content = c;
        this.time = d;
    }

    public String getNoteName(){return  name;}
    public String getNoteContent(){return  content;}
    public String getTime(){return  time;}
    public int getNoteId(){return  id;}


}