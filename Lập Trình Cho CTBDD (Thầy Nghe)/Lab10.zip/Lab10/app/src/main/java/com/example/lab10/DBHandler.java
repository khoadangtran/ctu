package com.example.lab10;

import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public  class DBHandler extends SQLiteOpenHelper {
    private static  final String dbName="MY_NOTE";
    private static final int dbVersion = 1;
    private static final String tableName = "NOTE";
    private static final String colName = "name";
    private static final String colContent = "content";

    public DBHandler(Context con){
        super(con, dbName, null, dbVersion);
    }

    @SuppressLint("Range")
    public ArrayList<NoteModel> readAllNote(){
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursorNote = db.rawQuery("SELECT * FROM " + tableName, null);

        ArrayList<NoteModel> listNote = new ArrayList<>();

        try {
            if (cursorNote.moveToFirst()) {
                do {
                    listNote.add(new NoteModel(
                            cursorNote.getInt(cursorNote.getColumnIndex("id")),
                            cursorNote.getString(cursorNote.getColumnIndex("name")),
                            cursorNote.getString(cursorNote.getColumnIndex("content")),
                            cursorNote.getString(cursorNote.getColumnIndex("createTime"))
                    ));
                } while (cursorNote.moveToNext());
            }
        } catch (Exception e) {
            e.printStackTrace(); // Handle or log exceptions properly
        } finally {
            cursorNote.close(); // Close the cursor in a finally block to ensure it's always closed
            db.close(); // Close the database connection after use
        }
        return  listNote;
    }
    @Override
    public void onCreate(SQLiteDatabase db) {
        String cmd = String.format("CREATE TABLE %s (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                "name TEXT not null," +
                "content TEXT, " +
                "createTime DATETIME DEFAULT CURRENT_TIMESTAMP)", tableName );
        db.execSQL(cmd);
    }

    public void addNewNote(String name, String content){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", name);
        values.put("content", content);
        db.insert(tableName, null, values);
        db.close();
    }

    public void updateNote(String oldName, String newName, String newContent, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(colName, newName);
        values.put(colContent, newContent);

        db.update(tableName, values, "name=? and createTime=?", new String[]{oldName, time});
        db.close();
    }

    public void deleteNote(String name, String time){
        SQLiteDatabase db = this.getWritableDatabase();
        db.delete(tableName, "name=? and createTime=?", new String[]{name, time});
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + tableName);
        onCreate(db);
    }
}
