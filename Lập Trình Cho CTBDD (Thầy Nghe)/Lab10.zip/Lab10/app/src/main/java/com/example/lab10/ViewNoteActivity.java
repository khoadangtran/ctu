package com.example.lab10;


import static androidx.constraintlayout.helper.widget.MotionEffect.TAG;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.ContextMenu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageButton;
import android.widget.Toast;

import java.util.ArrayList;

public class ViewNoteActivity extends AppCompatActivity {

    private ArrayList<NoteModel> noteList;
    private DBHandler db;
    private NoteRVAdapter RVAdapter;
    private RecyclerView noteRV;
    ImageButton btnback;
    int selectedPosition;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_note);

        noteList = new ArrayList<>();
        db = new DBHandler(ViewNoteActivity.this);
        noteList = db.readAllNote();

        RVAdapter = new NoteRVAdapter(noteList, ViewNoteActivity.this);
        noteRV = findViewById(R.id.RVnote);

        btnback = findViewById(R.id.btnBack);
        // setting layout manager for our recycler view.
        LinearLayoutManager layoutManager = new LinearLayoutManager(ViewNoteActivity.this,RecyclerView.VERTICAL, false);
        noteRV.setLayoutManager(layoutManager);

        noteRV.setAdapter(RVAdapter);

        registerForContextMenu(noteRV);


        btnback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(ViewNoteActivity.this, MainActivity.class);
                startActivity(i);
            }
        });
    }

    @Override
    public void onCreateContextMenu(ContextMenu menu, View v, ContextMenu.ContextMenuInfo menuInfo) {
        super.onCreateContextMenu(menu, v, menuInfo);
        MenuInflater infllater = getMenuInflater();
        infllater.inflate(R.menu.menu_activity, menu);
    }

    @Override
    public boolean onContextItemSelected(@NonNull MenuItem item) {
        int position = NoteRVAdapter.selectedNotePosition;
        NoteModel selectedNote = noteList.get(position);
        //Toast.makeText(this, x.getNoteName(), Toast.LENGTH_SHORT).show();
        String selectName = selectedNote.getNoteName();
        String selectTime = selectedNote.getTime();

        if(item.getItemId() == R.id.itemRemove){
            noteList.remove(position);
            db.deleteNote(selectName, selectTime);
            RVAdapter.notifyItemRemoved(position);
        }
        else if(item.getItemId() == R.id.itemEdit){
            Toast.makeText(this, NoteRVAdapter.selectedNote.getNoteName(), Toast.LENGTH_SHORT).show();
            Intent i = new Intent(ViewNoteActivity.this, UpdateNoteActivity.class);
            i.putExtra("name", selectedNote.getNoteName());
            i.putExtra("content", selectedNote.getNoteContent());
            i.putExtra("id", selectedNote.getNoteId());
            i.putExtra("time", selectedNote.getTime());
            startActivity(i);
        }
        return super.onContextItemSelected(item);

    }
}