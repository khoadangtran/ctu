package com.example.lab10;


import android.content.Context;
import android.util.Log;
import android.view.ContextMenu;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class NoteRVAdapter extends RecyclerView.Adapter<NoteRVAdapter.ViewHolder> {

    private ArrayList<NoteModel> listNote;
    private Context context;
    public static NoteModel selectedNote ;
    public static int selectedNotePosition ;
    public NoteRVAdapter(ArrayList<NoteModel> l, Context con){
        this.listNote = l;
        this.context = con;
    }
    @NonNull
    @Override
    public NoteRVAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.activity_note_review, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull NoteRVAdapter.ViewHolder holder, int position) {
        NoteModel note = listNote.get(position);
        holder.nameTV.setText(note.getNoteName());
        holder.contentTV.setText(note.getNoteContent());
        holder.timeTV.setText(note.getTime());
    }

    @Override
    public int getItemCount() {
        return listNote.size();
    }

    private static final String TAG = "NoteRVAdapter";
    public class ViewHolder extends RecyclerView.ViewHolder implements  View.OnLongClickListener{
        private TextView  nameTV, contentTV, timeTV;
        public ViewHolder(@NonNull View item){
            super(item);
            nameTV = item.findViewById(R.id.txtRVName);
            contentTV = item.findViewById(R.id.txtRVContent);
            timeTV = item.findViewById(R.id.txtRVDate);
            item.setOnLongClickListener(this);
        }

        @Override
        public boolean onLongClick(View v) {
            //Toast.makeText(context, getAdapterPosition(), Toast.LENGTH_SHORT).show();
            Log.d(TAG, "onLongClick: " + getAdapterPosition());
            selectedNote = listNote.get(getAdapterPosition());
            selectedNotePosition = getAdapterPosition();
            return false;
        }



    }

}

