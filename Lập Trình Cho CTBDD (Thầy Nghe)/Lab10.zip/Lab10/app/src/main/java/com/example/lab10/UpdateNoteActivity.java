package com.example.lab10;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import com.google.android.material.button.MaterialButton;

public class UpdateNoteActivity extends AppCompatActivity {
    ImageButton btnBack;
    MaterialButton btnSave;
    EditText txtName, txtContent;
    String oName, oContent, oTime;
    int id;

    DBHandler db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_note);
        db = new DBHandler(this);
        txtName = findViewById(R.id.txtUpdateName);
        txtContent = findViewById(R.id.txtUpdateContent);

        oName = getIntent().getStringExtra("name");
        oContent = getIntent().getStringExtra("content");
        oTime =getIntent().getStringExtra("time");
        id = getIntent().getIntExtra("id", 0);

        txtName.setText(oName);
        txtContent.setText(oContent);

        btnSave = findViewById(R.id.btnUpdateSave);

        btnBack = findViewById(R.id.btnUpdateBack);
        btnBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(UpdateNoteActivity.this, ViewNoteActivity.class);
                startActivity(i);
            }
        });


        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.updateNote(oName, txtName.getText().toString(), txtContent.getText().toString(), oTime);
                Toast.makeText(UpdateNoteActivity.this, "Updated item successfully", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateNoteActivity.this, ViewNoteActivity.class);
                startActivity(i);
            }
        });


    }
}
