package com.example.lab10;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.media.Image;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    Button btnSave, btnCancel;
    ImageButton btnViewNote;
    DBHandler db;
    EditText txtName, txtContent;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btnSave = findViewById(R.id.btnSave);
        btnCancel = findViewById(R.id.btnCancel);
        btnViewNote = findViewById(R.id.btnViewNote);

        txtName = findViewById(R.id.txtName);
        txtContent = findViewById(R.id.txtContent);

        db = new DBHandler(MainActivity.this);
        btnSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if(txtName.getText().toString().equals("")){
                    Toast.makeText(MainActivity.this, "Name of event is required", Toast.LENGTH_SHORT).show();
                }
                else {
                    try {
                        db.addNewNote(txtName.getText().toString(), txtContent.getText().toString());
                        Toast.makeText(MainActivity.this, "Add note successfully", Toast.LENGTH_SHORT).show();
                    }catch (Exception e){
                        Toast.makeText(MainActivity.this, "Add note failed", Toast.LENGTH_SHORT).show();
                    }
                }
                btnCancel.callOnClick();
            }
        });

        btnCancel.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                txtName.setText("");
                txtContent.setText("");
            }
        });

        btnViewNote.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this, ViewNoteActivity.class);
                startActivity(i);
            }
        });
    }
}